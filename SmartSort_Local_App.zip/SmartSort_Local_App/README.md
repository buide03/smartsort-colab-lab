> **Học sinh Windows: một câu lệnh tự tải môi trường và mở lab.** Xem [hướng dẫn dành cho học sinh](docs/CHO_HOC_SINH_WINDOWS.md). Không cần cài Git/PyTorch hoặc quyền quản trị; có nút mở lab trên Desktop.

```powershell
& ([scriptblock]::Create((Invoke-RestMethod 'https://raw.githubusercontent.com/buide03/smartsort-colab-lab/main/start-student.ps1')))
```

> **Bản miễn phí cho lớp học: Render Static Site + Colab GPU + validation/test trong trình duyệt.** Xem [hướng dẫn deploy và thao tác](docs/DEPLOY_RENDER_STATIC.md). Chạy thử bằng `python run_browser_lab.py`, mở http://127.0.0.1:8001/. Ảnh/phiên lưu trong trình duyệt, có ZIP sao lưu/khôi phục.

> **Oracle Always Free:** bản Docker có cấu hình ARM64, lưu trên ổ VM và HTTPS Caddy. Xem [hướng dẫn đăng ký, tạo VM và deploy](docs/DEPLOY_ORACLE.md).

> **Phương án Railway:** dùng Railway + Docker, volume `/data`, train bằng Colab GPU; học sinh chỉ cần URL web. Xem [hướng dẫn deploy và kiểm tra](docs/COLAB_VA_DEPLOY_RAILWAY.md). Workflow [Docker deployment checks](https://github.com/buide03/smartsort-colab-lab/actions) kiểm tra image và dữ liệu sau khi restart.

# SmartSort Classroom — huấn luyện, chốt mô hình và đánh giá test

**Trực quan kết quả test:** bước 5 có thư viện ảnh đúng/sai, bộ lọc từng vật liệu, độ tin cậy và xác suất ba lớp. Xem [hướng dẫn đọc kết quả trên ảnh](docs/XEM_KET_QUA_TEST.md). Model phân loại cả ảnh; không tạo khung vị trí vật thể.

**Sản phẩm chính: giao diện local dùng dạy học với ảnh chưa có nhãn.** Backend Python/FastAPI, giao diện HTML/CSS/JavaScript, mô hình EfficientNet-B0. Notebook Colab cũ bên dưới được giữ nguyên làm ví dụ với dữ liệu đã có nhãn.

## Bản triển khai lớp học: Colab + Docker/Railway

Luồng mới: **web gán nhãn/chia dữ liệu → xuất chỉ train → Colab GPU train → nhập checkpoint vào web → học sinh chạy validation → chốt cấu hình/epoch → chạy test**.

- [Notebook train Colab mới](https://colab.research.google.com/github/buide03/smartsort-colab-lab/blob/main/colab/SmartSort_Train_Colab.ipynb).
- [Hướng dẫn đầy đủ Colab và deploy Railway](docs/COLAB_VA_DEPLOY_RAILWAY.md).
- Có `Dockerfile`, `compose.yaml`, `railway.json`, healthcheck `/healthz`, volume `/data` và mã lớp tùy chọn.
- Bản Docker chỉ validation/test trên CPU server, không train local. Bản Python local giữ nút train máy để kiểm thử/đối chiếu.

```bash
docker compose up --build -d
```

Railway: deploy từ repo, gắn volume `/data`, đặt biến môi trường theo hướng dẫn rồi Generate Domain để có URL HTTPS cho học sinh. Mỗi service là phòng học dùng chung, các nhóm dùng phiên có tên riêng; chưa có tài khoản tách quyền giữa nhóm.

## Chạy giao diện local

Hướng dẫn đầy đủ cho người mới: **[Clone repo → tạo môi trường → cài đặt → chạy](docs/CAI_DAT_VA_CHAY.md)**. Repo public; người dùng có thể clone mà không cần được cấp quyền GitHub.

Chạy nhanh trên Windows PowerShell (CPU):

```powershell
git clone https://github.com/buide03/smartsort-colab-lab.git
cd smartsort-colab-lab
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install torch torchvision --index-url https://download.pytorch.org/whl/cpu
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe run_local.py
```

Mở **http://127.0.0.1:8000**. Giữ cửa sổ Python mở; `Ctrl+C` để dừng. Nếu đã tải ZIP local, bỏ hai lệnh clone/cd và mở terminal tại thư mục đã giải nén. Cổng khác: `.\.venv\Scripts\python.exe run_local.py --port 8001`.

Linux/macOS:

```bash
git clone https://github.com/buide03/smartsort-colab-lab.git
cd smartsort-colab-lab
python3 -m venv .venv
./.venv/bin/python -m pip install --upgrade pip
./.venv/bin/python -m pip install -r requirements.txt
./.venv/bin/python run_local.py
```

Python 3.10+, khuyến nghị 3.11/3.12; chạy được CPU, có CUDA thì dùng GPU. Lần đầu cần Internet để cài thư viện và tải trọng số ImageNet. Giao diện không dùng CDN; dữ liệu/nhãn/kết quả lưu tại `.smartsort/` và không push lên Git.

1. **Tải ảnh & gán nhãn:** mọi ảnh bắt đầu chưa có nhãn. Chọn Nhựa/Giấy/Kim loại hoặc Bỏ qua; có xem lớn, lọc ảnh, gán theo nhóm, tải CSV.
2. **Chia ba tập:** mặc định 70/15/15 theo từng lớp; lưu seed/manifest, khóa nhãn và giữ kín ảnh test.
3. **Huấn luyện & validation:** thử learning rate, xem learning curves, early stopping và checkpoint tốt nhất. Không đọc test.
4. **Chốt cấu hình:** chọn cấu hình đạt tiêu chí validation đặt trước; lưu checkpoint, epoch, ngưỡng và hash bản chia.
5. **Đánh giá test:** chỉ suy luận bằng checkpoint đã chốt; metrics từng lớp, confusion matrix, ảnh sai, nhận xét và ZIP báo cáo/mô hình.

Mỗi bước có giải thích và câu hỏi thảo luận. Xem [hướng dẫn dạy học, kịch bản buổi học và rubric](docs/HUONG_DAN_DAY_HOC.md), [kiểm thử local](docs/KIEM_THU_LOCAL.md). Tải [gói local](SmartSort_Local_App.zip) nếu không dùng Git clone.

Cần tối thiểu 10 ảnh khác nhau/lớp, khuyến nghị từ 50 ảnh/lớp. Ứng dụng không đoán nhãn từ thư mục/metadata, chỉ loại ảnh có pixel trùng hoàn toàn; ảnh gần giống/cùng vật thể cần kiểm tra thủ công. Bài toán phân loại toàn bộ ảnh, không phát hiện nhiều vật thể hay lớp unknown. Sau khi xem test và cải tiến, cần test mới độc lập.

![Giao diện SmartSort Classroom](docs/assets/local-preview.png)

Mã local: `smartsort_app/`, `run_local.py`, `start_local.ps1`. Kiểm tra: `pip install httpx`, rồi `python -m unittest discover -s tests -p test_workflow.py -v`. `tests/verify_browser.py` dùng Edge/Playwright và mô hình thật để kiểm thử toàn quy trình với nhãn tham chiếu làm fixture; ứng dụng không tự đọc nhãn đó.


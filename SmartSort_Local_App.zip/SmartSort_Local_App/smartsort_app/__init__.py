"""SmartSort teaching application."""
